--
-- PostgreSQL database dump
--

-- Dumped from database version 13.7
-- Dumped by pg_dump version 13.6 (Ubuntu 13.6-1.pgdg20.04+1+b1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP EVENT TRIGGER make_readable;
DROP EVENT TRIGGER forbid_ddl_reader;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_supplier_id_fkey;
ALTER TABLE ONLY public.supplier_frameworks DROP CONSTRAINT supplier_frameworks_supplier_id_fkey;
ALTER TABLE ONLY public.supplier_frameworks DROP CONSTRAINT supplier_frameworks_framework_id_fkey;
ALTER TABLE ONLY public.services DROP CONSTRAINT services_supplier_id_fkey;
ALTER TABLE ONLY public.services DROP CONSTRAINT services_lot_id_fkey;
ALTER TABLE ONLY public.services DROP CONSTRAINT services_framework_id_fkey1;
ALTER TABLE ONLY public.services DROP CONSTRAINT services_framework_id_fkey;
ALTER TABLE ONLY public.outcomes DROP CONSTRAINT outcomes_direct_award_search_id_fkey;
ALTER TABLE ONLY public.outcomes DROP CONSTRAINT outcomes_direct_award_project_id_fkey;
ALTER TABLE ONLY public.outcomes DROP CONSTRAINT outcomes_direct_award_archived_service_id_fkey;
ALTER TABLE ONLY public.outcomes DROP CONSTRAINT outcomes_brief_response_id_fkey;
ALTER TABLE ONLY public.outcomes DROP CONSTRAINT outcomes_brief_id_fkey;
ALTER TABLE ONLY public.framework_lots DROP CONSTRAINT framework_lots_lot_id_fkey;
ALTER TABLE ONLY public.framework_lots DROP CONSTRAINT framework_lots_framework_id_fkey;
ALTER TABLE ONLY public.framework_agreements DROP CONSTRAINT framework_agreements_supplier_id_fkey;
ALTER TABLE ONLY public.supplier_frameworks DROP CONSTRAINT fk_supplier_frameworks_supplier_id_supplier_frameworks;
ALTER TABLE ONLY public.supplier_frameworks DROP CONSTRAINT fk_supplier_frameworks_prefill_declaration_from_framework_id;
ALTER TABLE ONLY public.outcomes DROP CONSTRAINT fk_outcomes_da_service_id_da_search_id;
ALTER TABLE ONLY public.outcomes DROP CONSTRAINT fk_outcomes_da_search_id_da_project_id;
ALTER TABLE ONLY public.outcomes DROP CONSTRAINT fk_outcomes_brief_response_id_brief_id;
ALTER TABLE ONLY public.draft_services DROP CONSTRAINT fk_draft_services_lot_id_one_service_limit;
ALTER TABLE ONLY public.draft_services DROP CONSTRAINT draft_services_supplier_id_fkey;
ALTER TABLE ONLY public.draft_services DROP CONSTRAINT draft_services_lot_id_fkey;
ALTER TABLE ONLY public.draft_services DROP CONSTRAINT draft_services_framework_id_fkey1;
ALTER TABLE ONLY public.draft_services DROP CONSTRAINT draft_services_framework_id_fkey;
ALTER TABLE ONLY public.direct_award_searches DROP CONSTRAINT direct_award_searches_project_id_fkey;
ALTER TABLE ONLY public.direct_award_searches DROP CONSTRAINT direct_award_searches_created_by_fkey;
ALTER TABLE ONLY public.direct_award_search_result_entries DROP CONSTRAINT direct_award_search_result_entries_search_id_fkey;
ALTER TABLE ONLY public.direct_award_search_result_entries DROP CONSTRAINT direct_award_search_result_entries_archived_service_id_fkey;
ALTER TABLE ONLY public.direct_award_project_users DROP CONSTRAINT direct_award_project_users_user_id_fkey;
ALTER TABLE ONLY public.direct_award_project_users DROP CONSTRAINT direct_award_project_users_project_id_fkey;
ALTER TABLE ONLY public.contact_information DROP CONSTRAINT contact_information_supplier_id_fkey;
ALTER TABLE ONLY public.briefs DROP CONSTRAINT briefs_lot_id_fkey;
ALTER TABLE ONLY public.briefs DROP CONSTRAINT briefs_framework_id_fkey1;
ALTER TABLE ONLY public.briefs DROP CONSTRAINT briefs_framework_id_fkey;
ALTER TABLE ONLY public.brief_users DROP CONSTRAINT brief_users_user_id_fkey;
ALTER TABLE ONLY public.brief_users DROP CONSTRAINT brief_users_brief_id_fkey;
ALTER TABLE ONLY public.brief_responses DROP CONSTRAINT brief_responses_supplier_id_fkey;
ALTER TABLE ONLY public.brief_responses DROP CONSTRAINT brief_responses_brief_id_fkey;
ALTER TABLE ONLY public.brief_clarification_questions DROP CONSTRAINT brief_clarification_questions_brief_id_fkey;
ALTER TABLE ONLY public.archived_services DROP CONSTRAINT archived_services_supplier_id_fkey;
ALTER TABLE ONLY public.archived_services DROP CONSTRAINT archived_services_lot_id_fkey;
ALTER TABLE ONLY public.archived_services DROP CONSTRAINT archived_services_framework_id_fkey1;
ALTER TABLE ONLY public.archived_services DROP CONSTRAINT archived_services_framework_id_fkey;
DROP INDEX public.ix_users_supplier_id;
DROP INDEX public.ix_suppliers_supplier_id;
DROP INDEX public.ix_services_supplier_id;
DROP INDEX public.ix_services_lot_id;
DROP INDEX public.ix_services_framework_id;
DROP INDEX public.ix_service_ordering;
DROP INDEX public.ix_lots_slug;
DROP INDEX public.ix_frameworks_status;
DROP INDEX public.ix_frameworks_slug;
DROP INDEX public.ix_frameworks_framework;
DROP INDEX public.ix_draft_services_supplier_id;
DROP INDEX public.ix_draft_services_service_id;
DROP INDEX public.ix_draft_services_lot_id;
DROP INDEX public.ix_draft_services_framework_id;
DROP INDEX public.ix_direct_award_searches_project_id;
DROP INDEX public.ix_direct_award_searches_active;
DROP INDEX public.ix_direct_award_search_result_entries_search_id;
DROP INDEX public.ix_direct_award_search_result_entries_archived_service_id;
DROP INDEX public.ix_direct_award_project_users_user_id;
DROP INDEX public.ix_direct_award_project_users_project_id;
DROP INDEX public.ix_briefs_withdrawn_at;
DROP INDEX public.ix_briefs_updated_at;
DROP INDEX public.ix_briefs_unsuccessful_at;
DROP INDEX public.ix_briefs_published_at;
DROP INDEX public.ix_briefs_created_at;
DROP INDEX public.ix_briefs_cancelled_at;
DROP INDEX public.ix_brief_responses_created_at;
DROP INDEX public.ix_brief_clarification_questions_published_at;
DROP INDEX public.ix_audit_events_type;
DROP INDEX public.ix_audit_events_created_at;
DROP INDEX public.ix_audit_events_acknowledged;
DROP INDEX public.ix_archived_services_supplier_id;
DROP INDEX public.ix_archived_services_service_id;
DROP INDEX public.ix_archived_services_lot_id;
DROP INDEX public.ix_archived_services_framework_id;
DROP INDEX public.idx_project_id_active;
DROP INDEX public.idx_outcomes_completed_direct_award_project_unique;
DROP INDEX public.idx_outcomes_completed_brief_unique;
DROP INDEX public.idx_draft_services_enforce_one_service_limit;
DROP INDEX public.idx_brief_responses_unique_awarded_at_per_brief_id;
DROP INDEX public.idx_audit_events_type_acknowledged;
DROP INDEX public.idx_audit_events_object_and_type;
DROP INDEX public.idx_audit_events_data_supplier_id;
DROP INDEX public.idx_audit_events_data_draft_id;
DROP INDEX public.idx_audit_events_created_at_per_obj_partial;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_pkey;
ALTER TABLE ONLY public.users DROP CONSTRAINT uq_users_email_address;
ALTER TABLE ONLY public.suppliers DROP CONSTRAINT uq_suppliers_duns_number;
ALTER TABLE ONLY public.services DROP CONSTRAINT uq_services_service_id;
ALTER TABLE ONLY public.outcomes DROP CONSTRAINT uq_outcomes_external_id;
ALTER TABLE ONLY public.lots DROP CONSTRAINT uq_lots_id_one_service_limit;
ALTER TABLE ONLY public.direct_award_searches DROP CONSTRAINT uq_direct_award_searches_id_project_id;
ALTER TABLE ONLY public.direct_award_search_result_entries DROP CONSTRAINT uq_direct_award_search_result_entries_archived_service_id_searc;
ALTER TABLE ONLY public.direct_award_projects DROP CONSTRAINT uq_direct_award_projects_external_id;
ALTER TABLE ONLY public.buyer_email_domains DROP CONSTRAINT uq_buyer_email_domains_domain_name;
ALTER TABLE ONLY public.brief_responses DROP CONSTRAINT uq_brief_responses_id_brief_id;
ALTER TABLE ONLY public.suppliers DROP CONSTRAINT suppliers_pkey;
ALTER TABLE ONLY public.supplier_frameworks DROP CONSTRAINT supplier_frameworks_pkey;
ALTER TABLE ONLY public.services DROP CONSTRAINT services_pkey;
ALTER TABLE ONLY public.outcomes DROP CONSTRAINT outcomes_pkey;
ALTER TABLE ONLY public.lots DROP CONSTRAINT lots_pkey;
ALTER TABLE ONLY public.frameworks DROP CONSTRAINT frameworks_pkey;
ALTER TABLE ONLY public.framework_lots DROP CONSTRAINT framework_lots_pkey;
ALTER TABLE ONLY public.framework_agreements DROP CONSTRAINT framework_agreements_pkey;
ALTER TABLE ONLY public.draft_services DROP CONSTRAINT draft_services_pkey;
ALTER TABLE ONLY public.direct_award_searches DROP CONSTRAINT direct_award_searches_pkey;
ALTER TABLE ONLY public.direct_award_search_result_entries DROP CONSTRAINT direct_award_search_result_entries_pkey;
ALTER TABLE ONLY public.direct_award_projects DROP CONSTRAINT direct_award_projects_pkey;
ALTER TABLE ONLY public.direct_award_project_users DROP CONSTRAINT direct_award_project_users_pkey;
ALTER TABLE ONLY public.contact_information DROP CONSTRAINT contact_information_pkey;
ALTER TABLE ONLY public.buyer_email_domains DROP CONSTRAINT buyer_email_domains_pkey;
ALTER TABLE ONLY public.briefs DROP CONSTRAINT briefs_pkey;
ALTER TABLE ONLY public.brief_users DROP CONSTRAINT brief_users_pkey;
ALTER TABLE ONLY public.brief_responses DROP CONSTRAINT brief_responses_pkey;
ALTER TABLE ONLY public.brief_clarification_questions DROP CONSTRAINT brief_clarification_questions_pkey;
ALTER TABLE ONLY public.audit_events DROP CONSTRAINT audit_events_pkey;
ALTER TABLE ONLY public.archived_services DROP CONSTRAINT archived_services_pkey;
ALTER TABLE public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.suppliers ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.services ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.outcomes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.lots ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.frameworks ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.framework_agreements ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.draft_services ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.direct_award_searches ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.direct_award_search_result_entries ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.direct_award_projects ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.direct_award_project_users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.contact_information ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.buyer_email_domains ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.briefs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.brief_responses ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.brief_clarification_questions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.audit_events ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.archived_services ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.users_id_seq;
DROP TABLE public.users;
DROP SEQUENCE public.suppliers_id_seq;
DROP TABLE public.suppliers;
DROP SEQUENCE public.suppliers_supplier_id_seq;
DROP TABLE public.supplier_frameworks;
DROP SEQUENCE public.services_id_seq;
DROP TABLE public.services;
DROP SEQUENCE public.outcomes_id_seq;
DROP TABLE public.outcomes;
DROP SEQUENCE public.lots_id_seq;
DROP TABLE public.lots;
DROP SEQUENCE public.frameworks_id_seq;
DROP TABLE public.frameworks;
DROP TABLE public.framework_lots;
DROP SEQUENCE public.framework_agreements_id_seq;
DROP TABLE public.framework_agreements;
DROP SEQUENCE public.draft_services_id_seq;
DROP TABLE public.draft_services;
DROP SEQUENCE public.direct_award_searches_id_seq;
DROP TABLE public.direct_award_searches;
DROP SEQUENCE public.direct_award_search_result_entries_id_seq;
DROP TABLE public.direct_award_search_result_entries;
DROP SEQUENCE public.direct_award_projects_id_seq;
DROP TABLE public.direct_award_projects;
DROP SEQUENCE public.direct_award_project_users_id_seq;
DROP TABLE public.direct_award_project_users;
DROP SEQUENCE public.contact_information_id_seq;
DROP TABLE public.contact_information;
DROP SEQUENCE public.buyer_email_domains_id_seq;
DROP TABLE public.buyer_email_domains;
DROP SEQUENCE public.briefs_id_seq;
DROP TABLE public.briefs;
DROP TABLE public.brief_users;
DROP SEQUENCE public.brief_responses_id_seq;
DROP TABLE public.brief_responses;
DROP SEQUENCE public.brief_clarification_questions_id_seq;
DROP TABLE public.brief_clarification_questions;
DROP SEQUENCE public.audit_events_id_seq;
DROP TABLE public.audit_events;
DROP SEQUENCE public.archived_services_id_seq;
DROP TABLE public.archived_services;
DROP TABLE public.alembic_version;
DROP FUNCTION public.reassign_owned();
DROP FUNCTION public.make_readable_generic();
DROP FUNCTION public.make_readable();
DROP FUNCTION public.forbid_ddl_reader();
DROP TYPE public.user_roles_enum;
DROP EXTENSION "uuid-ossp";
DROP EXTENSION citext;
--
-- Name: citext; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS citext WITH SCHEMA public;


--
-- Name: EXTENSION citext; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION citext IS 'data type for case-insensitive character strings';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: user_roles_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.user_roles_enum AS ENUM (
    'buyer',
    'supplier',
    'admin',
    'admin-ccs',
    'admin-ccs-category',
    'admin-ccs-sourcing',
    'admin-manager',
    'admin-framework-manager',
    'admin-ccs-data-controller'
);


--
-- Name: forbid_ddl_reader(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.forbid_ddl_reader() RETURNS event_trigger
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
	begin
		-- do not execute if member of rds_superuser
		IF EXISTS (select 1 from pg_catalog.pg_roles where rolname = 'rds_superuser')
		AND pg_has_role(current_user, 'rds_superuser', 'member') THEN
			RETURN;
		END IF;

		-- do not execute if superuser
		IF EXISTS (SELECT 1 FROM pg_user WHERE usename = current_user and usesuper = true) THEN
			RETURN;
		END IF;

		-- do not execute if member of manager role
		IF pg_has_role(current_user, 'rdsbroker_manager', 'member') THEN
			RETURN;
		END IF;

		IF pg_has_role(current_user, 'rdsbroker_reader', 'member') THEN
			RAISE EXCEPTION 'executing % is disabled for read only bindings', tg_tag;
		END IF;
	end
$$;


--
-- Name: make_readable(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.make_readable() RETURNS event_trigger
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
	begin
		IF EXISTS (SELECT 1 FROM pg_event_trigger_ddl_commands() WHERE schema_name NOT LIKE 'pg_temp%') THEN
			EXECUTE 'select make_readable_generic()';
			RETURN;
		END IF;
	end
	$$;


--
-- Name: make_readable_generic(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.make_readable_generic() RETURNS void
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
	declare
		r record;
	begin
		-- do not execute if member of rds_superuser
		IF EXISTS (select 1 from pg_catalog.pg_roles where rolname = 'rds_superuser')
		AND pg_has_role(current_user, 'rds_superuser', 'member') THEN
			RETURN;
		END IF;

		-- do not execute if superuser
		IF EXISTS (SELECT 1 FROM pg_user WHERE usename = current_user and usesuper = true) THEN
			RETURN;
		END IF;

		-- do not execute if not member of manager role
		IF NOT pg_has_role(current_user, 'rdsbroker_manager', 'member') THEN
			RETURN;
		END IF;

		FOR r in (select schema_name from information_schema.schemata) LOOP
			BEGIN
				EXECUTE format('GRANT SELECT ON ALL TABLES IN SCHEMA %I TO %I', r.schema_name, 'rdsbroker_reader');
				EXECUTE format('GRANT SELECT ON ALL SEQUENCES IN SCHEMA %I TO %I', r.schema_name, 'rdsbroker_reader');
				EXECUTE format('GRANT USAGE ON SCHEMA %I TO %I', r.schema_name, 'rdsbroker_reader');

				RAISE NOTICE 'GRANTED READ ONLY IN SCHEMA %s', r.schema_name;
			EXCEPTION WHEN OTHERS THEN
			  -- brrr
			END;
		END LOOP;

		RETURN;
	end
$$;


--
-- Name: reassign_owned(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.reassign_owned() RETURNS event_trigger
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
	begin
		-- do not execute if member of rds_superuser
		IF EXISTS (select 1 from pg_catalog.pg_roles where rolname = 'rds_superuser')
		AND pg_has_role(current_user, 'rds_superuser', 'member') THEN
			RETURN;
		END IF;

		-- do not execute if superuser
		IF EXISTS (SELECT 1 FROM pg_user WHERE usename = current_user and usesuper = true) THEN
			RETURN;
		END IF;

		-- do not execute if not member of manager role
		IF NOT pg_has_role(current_user, 'rdsbroker_manager', 'member') THEN
			RETURN;
		END IF;

		EXECUTE format('REASSIGN OWNED BY %I TO %I', current_user, 'rdsbroker_manager');

		RETURN;
	end
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: archived_services; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.archived_services (
    id integer NOT NULL,
    service_id character varying(255) NOT NULL,
    supplier_id bigint NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    data json NOT NULL,
    status character varying NOT NULL,
    framework_id bigint NOT NULL,
    lot_id bigint NOT NULL,
    copied_to_following_framework boolean DEFAULT false NOT NULL,
    CONSTRAINT ck_archived_services_status CHECK (((status)::text = ANY (ARRAY['disabled'::text, 'enabled'::text, 'published'::text, 'deleted'::text])))
);


--
-- Name: archived_services_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.archived_services_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: archived_services_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.archived_services_id_seq OWNED BY public.archived_services.id;


--
-- Name: audit_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_events (
    id integer NOT NULL,
    type character varying NOT NULL,
    created_at timestamp without time zone NOT NULL,
    "user" character varying,
    data jsonb NOT NULL,
    object_type character varying,
    object_id bigint,
    acknowledged boolean NOT NULL,
    acknowledged_by character varying,
    acknowledged_at timestamp without time zone
);


--
-- Name: audit_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.audit_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audit_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.audit_events_id_seq OWNED BY public.audit_events.id;


--
-- Name: brief_clarification_questions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.brief_clarification_questions (
    id integer NOT NULL,
    brief_id integer NOT NULL,
    question character varying NOT NULL,
    answer character varying NOT NULL,
    published_at timestamp without time zone NOT NULL
);


--
-- Name: brief_clarification_questions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.brief_clarification_questions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: brief_clarification_questions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.brief_clarification_questions_id_seq OWNED BY public.brief_clarification_questions.id;


--
-- Name: brief_responses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.brief_responses (
    id integer NOT NULL,
    data json NOT NULL,
    brief_id integer NOT NULL,
    supplier_id integer NOT NULL,
    created_at timestamp without time zone NOT NULL,
    submitted_at timestamp without time zone,
    award_details json DEFAULT '{}'::json,
    awarded_at timestamp without time zone
);


--
-- Name: brief_responses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.brief_responses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: brief_responses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.brief_responses_id_seq OWNED BY public.brief_responses.id;


--
-- Name: brief_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.brief_users (
    brief_id integer NOT NULL,
    user_id integer NOT NULL
);


--
-- Name: briefs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.briefs (
    id integer NOT NULL,
    data json NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    framework_id integer NOT NULL,
    lot_id integer NOT NULL,
    published_at timestamp without time zone,
    withdrawn_at timestamp without time zone,
    is_a_copy boolean DEFAULT false NOT NULL,
    cancelled_at timestamp without time zone,
    unsuccessful_at timestamp without time zone
);


--
-- Name: briefs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.briefs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: briefs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.briefs_id_seq OWNED BY public.briefs.id;


--
-- Name: buyer_email_domains; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.buyer_email_domains (
    id integer NOT NULL,
    domain_name character varying NOT NULL
);


--
-- Name: buyer_email_domains_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.buyer_email_domains_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: buyer_email_domains_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.buyer_email_domains_id_seq OWNED BY public.buyer_email_domains.id;


--
-- Name: contact_information; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contact_information (
    id integer NOT NULL,
    supplier_id integer,
    contact_name character varying NOT NULL,
    phone_number character varying,
    email character varying NOT NULL,
    address1 character varying,
    city character varying,
    postcode character varying,
    personal_data_removed boolean DEFAULT false NOT NULL
);


--
-- Name: contact_information_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.contact_information_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: contact_information_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.contact_information_id_seq OWNED BY public.contact_information.id;


--
-- Name: direct_award_project_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.direct_award_project_users (
    id integer NOT NULL,
    project_id integer NOT NULL,
    user_id integer NOT NULL
);


--
-- Name: direct_award_project_users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.direct_award_project_users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: direct_award_project_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.direct_award_project_users_id_seq OWNED BY public.direct_award_project_users.id;


--
-- Name: direct_award_projects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.direct_award_projects (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    created_at timestamp without time zone NOT NULL,
    locked_at timestamp without time zone,
    active boolean NOT NULL,
    downloaded_at timestamp without time zone,
    external_id bigint NOT NULL,
    still_assessing_at timestamp without time zone,
    ready_to_assess_at timestamp without time zone
);


--
-- Name: direct_award_projects_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.direct_award_projects_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: direct_award_projects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.direct_award_projects_id_seq OWNED BY public.direct_award_projects.id;


--
-- Name: direct_award_search_result_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.direct_award_search_result_entries (
    id integer NOT NULL,
    search_id integer NOT NULL,
    archived_service_id integer NOT NULL
);


--
-- Name: direct_award_search_result_entries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.direct_award_search_result_entries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: direct_award_search_result_entries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.direct_award_search_result_entries_id_seq OWNED BY public.direct_award_search_result_entries.id;


--
-- Name: direct_award_searches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.direct_award_searches (
    id integer NOT NULL,
    created_by integer NOT NULL,
    project_id integer NOT NULL,
    created_at timestamp without time zone NOT NULL,
    searched_at timestamp without time zone,
    search_url text NOT NULL,
    active boolean NOT NULL
);


--
-- Name: direct_award_searches_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.direct_award_searches_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: direct_award_searches_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.direct_award_searches_id_seq OWNED BY public.direct_award_searches.id;


--
-- Name: draft_services; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.draft_services (
    id integer NOT NULL,
    service_id character varying,
    supplier_id bigint NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    data json NOT NULL,
    framework_id bigint NOT NULL,
    status character varying NOT NULL,
    lot_id bigint NOT NULL,
    copied_to_following_framework boolean DEFAULT false NOT NULL,
    lot_one_service_limit boolean NOT NULL
);


--
-- Name: draft_services_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.draft_services_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: draft_services_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.draft_services_id_seq OWNED BY public.draft_services.id;


--
-- Name: framework_agreements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.framework_agreements (
    id integer NOT NULL,
    supplier_id integer NOT NULL,
    framework_id integer NOT NULL,
    signed_agreement_returned_at timestamp without time zone,
    signed_agreement_details json,
    signed_agreement_path character varying,
    countersigned_agreement_details json,
    countersigned_agreement_path character varying,
    countersigned_agreement_returned_at timestamp without time zone,
    signed_agreement_put_on_hold_at timestamp without time zone
);


--
-- Name: framework_agreements_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.framework_agreements_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: framework_agreements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.framework_agreements_id_seq OWNED BY public.framework_agreements.id;


--
-- Name: framework_lots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.framework_lots (
    framework_id integer NOT NULL,
    lot_id integer NOT NULL
);


--
-- Name: frameworks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.frameworks (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    framework character varying NOT NULL,
    status character varying NOT NULL,
    slug character varying NOT NULL,
    clarification_questions_open boolean NOT NULL,
    framework_agreement_details json,
    allow_declaration_reuse boolean DEFAULT false NOT NULL,
    applications_close_at_utc timestamp without time zone NOT NULL,
    clarifications_close_at_utc timestamp without time zone NOT NULL,
    clarifications_publish_at_utc timestamp without time zone NOT NULL,
    framework_expires_at_utc timestamp without time zone NOT NULL,
    framework_live_at_utc timestamp without time zone NOT NULL,
    intention_to_award_at_utc timestamp without time zone NOT NULL,
    has_direct_award boolean NOT NULL,
    has_further_competition boolean NOT NULL,
    CONSTRAINT ck_framework_has_direct_award_or_further_competition CHECK (((has_direct_award IS TRUE) OR (has_further_competition IS TRUE)))
);


--
-- Name: frameworks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.frameworks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: frameworks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.frameworks_id_seq OWNED BY public.frameworks.id;


--
-- Name: lots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lots (
    id integer NOT NULL,
    slug character varying NOT NULL,
    name character varying NOT NULL,
    one_service_limit boolean NOT NULL,
    data json
);


--
-- Name: lots_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.lots_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: lots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.lots_id_seq OWNED BY public.lots.id;


--
-- Name: outcomes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.outcomes (
    id integer NOT NULL,
    external_id bigint NOT NULL,
    completed_at timestamp without time zone,
    start_date date,
    end_date date,
    awarding_organisation_name character varying,
    award_value numeric(11,2),
    result character varying NOT NULL,
    direct_award_project_id integer,
    direct_award_search_id integer,
    direct_award_archived_service_id integer,
    brief_id integer,
    brief_response_id integer,
    CONSTRAINT ck_outcomes_brief_keys_nullable CHECK (
CASE
    WHEN ((result)::text = 'awarded'::text) THEN ((brief_response_id IS NULL) = (brief_id IS NULL))
    ELSE (brief_response_id IS NULL)
END),
    CONSTRAINT ck_outcomes_direct_award_keys_nullable CHECK (
CASE
    WHEN ((result)::text = 'awarded'::text) THEN (((direct_award_project_id IS NULL) = (direct_award_search_id IS NULL)) AND ((direct_award_project_id IS NULL) = (direct_award_archived_service_id IS NULL)))
    ELSE ((direct_award_search_id IS NULL) AND (direct_award_archived_service_id IS NULL))
END),
    CONSTRAINT ck_outcomes_either_brief_xor_direct_award CHECK (((direct_award_project_id IS NULL) <> (brief_id IS NULL)))
);


--
-- Name: outcomes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.outcomes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: outcomes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.outcomes_id_seq OWNED BY public.outcomes.id;


--
-- Name: services; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.services (
    id integer NOT NULL,
    data json NOT NULL,
    service_id character varying(255) NOT NULL,
    created_at timestamp without time zone NOT NULL,
    supplier_id bigint NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    status character varying NOT NULL,
    framework_id bigint NOT NULL,
    lot_id bigint NOT NULL,
    copied_to_following_framework boolean DEFAULT false NOT NULL,
    CONSTRAINT ck_services_status CHECK (((status)::text = ANY (ARRAY['disabled'::text, 'enabled'::text, 'published'::text, 'deleted'::text])))
);


--
-- Name: services_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.services_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: services_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.services_id_seq OWNED BY public.services.id;


--
-- Name: supplier_frameworks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.supplier_frameworks (
    supplier_id integer NOT NULL,
    framework_id integer NOT NULL,
    declaration json,
    on_framework boolean,
    agreed_variations json,
    prefill_declaration_from_framework_id integer,
    application_company_details_confirmed boolean,
    allow_declaration_reuse boolean DEFAULT true NOT NULL
);


--
-- Name: suppliers_supplier_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.suppliers_supplier_id_seq
    START WITH 700000
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: suppliers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.suppliers (
    id integer NOT NULL,
    supplier_id bigint DEFAULT nextval('public.suppliers_supplier_id_seq'::regclass) NOT NULL,
    name character varying(255) NOT NULL,
    duns_number character varying,
    description character varying,
    companies_house_number character varying,
    registered_name character varying,
    registration_country character varying,
    other_company_registration_number character varying,
    vat_number character varying,
    organisation_size character varying,
    trading_status character varying,
    company_details_confirmed boolean DEFAULT false NOT NULL,
    active boolean DEFAULT true NOT NULL
);


--
-- Name: suppliers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.suppliers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: suppliers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.suppliers_id_seq OWNED BY public.suppliers.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    name character varying NOT NULL,
    email_address character varying NOT NULL,
    password character varying NOT NULL,
    active boolean NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    password_changed_at timestamp without time zone NOT NULL,
    role public.user_roles_enum NOT NULL,
    supplier_id bigint,
    failed_login_count integer NOT NULL,
    logged_in_at timestamp without time zone,
    phone_number character varying,
    user_research_opted_in boolean DEFAULT false NOT NULL,
    personal_data_removed boolean DEFAULT false NOT NULL
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: archived_services id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.archived_services ALTER COLUMN id SET DEFAULT nextval('public.archived_services_id_seq'::regclass);


--
-- Name: audit_events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_events ALTER COLUMN id SET DEFAULT nextval('public.audit_events_id_seq'::regclass);


--
-- Name: brief_clarification_questions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.brief_clarification_questions ALTER COLUMN id SET DEFAULT nextval('public.brief_clarification_questions_id_seq'::regclass);


--
-- Name: brief_responses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.brief_responses ALTER COLUMN id SET DEFAULT nextval('public.brief_responses_id_seq'::regclass);


--
-- Name: briefs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.briefs ALTER COLUMN id SET DEFAULT nextval('public.briefs_id_seq'::regclass);


--
-- Name: buyer_email_domains id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.buyer_email_domains ALTER COLUMN id SET DEFAULT nextval('public.buyer_email_domains_id_seq'::regclass);


--
-- Name: contact_information id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contact_information ALTER COLUMN id SET DEFAULT nextval('public.contact_information_id_seq'::regclass);


--
-- Name: direct_award_project_users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.direct_award_project_users ALTER COLUMN id SET DEFAULT nextval('public.direct_award_project_users_id_seq'::regclass);


--
-- Name: direct_award_projects id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.direct_award_projects ALTER COLUMN id SET DEFAULT nextval('public.direct_award_projects_id_seq'::regclass);


--
-- Name: direct_award_search_result_entries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.direct_award_search_result_entries ALTER COLUMN id SET DEFAULT nextval('public.direct_award_search_result_entries_id_seq'::regclass);


--
-- Name: direct_award_searches id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.direct_award_searches ALTER COLUMN id SET DEFAULT nextval('public.direct_award_searches_id_seq'::regclass);


--
-- Name: draft_services id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.draft_services ALTER COLUMN id SET DEFAULT nextval('public.draft_services_id_seq'::regclass);


--
-- Name: framework_agreements id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.framework_agreements ALTER COLUMN id SET DEFAULT nextval('public.framework_agreements_id_seq'::regclass);


--
-- Name: frameworks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frameworks ALTER COLUMN id SET DEFAULT nextval('public.frameworks_id_seq'::regclass);


--
-- Name: lots id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lots ALTER COLUMN id SET DEFAULT nextval('public.lots_id_seq'::regclass);


--
-- Name: outcomes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.outcomes ALTER COLUMN id SET DEFAULT nextval('public.outcomes_id_seq'::regclass);


--
-- Name: services id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services ALTER COLUMN id SET DEFAULT nextval('public.services_id_seq'::regclass);


--
-- Name: suppliers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suppliers ALTER COLUMN id SET DEFAULT nextval('public.suppliers_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alembic_version (version_num) FROM stdin;
1460
\.



--
-- Name: archived_services_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.archived_services_id_seq', 575326, true);


--
-- Name: audit_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.audit_events_id_seq', 9489704, true);


--
-- Name: brief_clarification_questions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.brief_clarification_questions_id_seq', 54723, true);


--
-- Name: brief_responses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.brief_responses_id_seq', 124006, true);


--
-- Name: briefs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.briefs_id_seq', 16506, true);


--
-- Name: buyer_email_domains_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.buyer_email_domains_id_seq', 730, true);


--
-- Name: contact_information_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.contact_information_id_seq', 30004, true);


--
-- Name: direct_award_project_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.direct_award_project_users_id_seq', 28580, true);


--
-- Name: direct_award_projects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.direct_award_projects_id_seq', 28580, true);


--
-- Name: direct_award_search_result_entries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.direct_award_search_result_entries_id_seq', 183373, true);


--
-- Name: direct_award_searches_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.direct_award_searches_id_seq', 36129, true);


--
-- Name: draft_services_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.draft_services_id_seq', 280849, true);


--
-- Name: framework_agreements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.framework_agreements_id_seq', 39757, true);


--
-- Name: frameworks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.frameworks_id_seq', 16, true);


--
-- Name: lots_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.lots_id_seq', 12, true);


--
-- Name: outcomes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.outcomes_id_seq', 3714, true);


--
-- Name: services_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.services_id_seq', 322437, true);


--
-- Name: suppliers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.suppliers_id_seq', 30062, true);


--
-- Name: suppliers_supplier_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.suppliers_supplier_id_seq', 720792, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 78507, true);


--
-- Name: archived_services archived_services_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.archived_services
    ADD CONSTRAINT archived_services_pkey PRIMARY KEY (id);


--
-- Name: audit_events audit_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_events
    ADD CONSTRAINT audit_events_pkey PRIMARY KEY (id);


--
-- Name: brief_clarification_questions brief_clarification_questions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.brief_clarification_questions
    ADD CONSTRAINT brief_clarification_questions_pkey PRIMARY KEY (id);


--
-- Name: brief_responses brief_responses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.brief_responses
    ADD CONSTRAINT brief_responses_pkey PRIMARY KEY (id);


--
-- Name: brief_users brief_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.brief_users
    ADD CONSTRAINT brief_users_pkey PRIMARY KEY (brief_id, user_id);


--
-- Name: briefs briefs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.briefs
    ADD CONSTRAINT briefs_pkey PRIMARY KEY (id);


--
-- Name: buyer_email_domains buyer_email_domains_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.buyer_email_domains
    ADD CONSTRAINT buyer_email_domains_pkey PRIMARY KEY (id);


--
-- Name: contact_information contact_information_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contact_information
    ADD CONSTRAINT contact_information_pkey PRIMARY KEY (id);


--
-- Name: direct_award_project_users direct_award_project_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.direct_award_project_users
    ADD CONSTRAINT direct_award_project_users_pkey PRIMARY KEY (id);


--
-- Name: direct_award_projects direct_award_projects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.direct_award_projects
    ADD CONSTRAINT direct_award_projects_pkey PRIMARY KEY (id);


--
-- Name: direct_award_search_result_entries direct_award_search_result_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.direct_award_search_result_entries
    ADD CONSTRAINT direct_award_search_result_entries_pkey PRIMARY KEY (id);


--
-- Name: direct_award_searches direct_award_searches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.direct_award_searches
    ADD CONSTRAINT direct_award_searches_pkey PRIMARY KEY (id);


--
-- Name: draft_services draft_services_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.draft_services
    ADD CONSTRAINT draft_services_pkey PRIMARY KEY (id);


--
-- Name: framework_agreements framework_agreements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.framework_agreements
    ADD CONSTRAINT framework_agreements_pkey PRIMARY KEY (id);


--
-- Name: framework_lots framework_lots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.framework_lots
    ADD CONSTRAINT framework_lots_pkey PRIMARY KEY (framework_id, lot_id);


--
-- Name: frameworks frameworks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frameworks
    ADD CONSTRAINT frameworks_pkey PRIMARY KEY (id);


--
-- Name: lots lots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lots
    ADD CONSTRAINT lots_pkey PRIMARY KEY (id);


--
-- Name: outcomes outcomes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.outcomes
    ADD CONSTRAINT outcomes_pkey PRIMARY KEY (id);


--
-- Name: services services_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_pkey PRIMARY KEY (id);


--
-- Name: supplier_frameworks supplier_frameworks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplier_frameworks
    ADD CONSTRAINT supplier_frameworks_pkey PRIMARY KEY (supplier_id, framework_id);


--
-- Name: suppliers suppliers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_pkey PRIMARY KEY (id);


--
-- Name: brief_responses uq_brief_responses_id_brief_id; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.brief_responses
    ADD CONSTRAINT uq_brief_responses_id_brief_id UNIQUE (id, brief_id);


--
-- Name: buyer_email_domains uq_buyer_email_domains_domain_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.buyer_email_domains
    ADD CONSTRAINT uq_buyer_email_domains_domain_name UNIQUE (domain_name);


--
-- Name: direct_award_projects uq_direct_award_projects_external_id; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.direct_award_projects
    ADD CONSTRAINT uq_direct_award_projects_external_id UNIQUE (external_id);


--
-- Name: direct_award_search_result_entries uq_direct_award_search_result_entries_archived_service_id_searc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.direct_award_search_result_entries
    ADD CONSTRAINT uq_direct_award_search_result_entries_archived_service_id_searc UNIQUE (archived_service_id, search_id);


--
-- Name: direct_award_searches uq_direct_award_searches_id_project_id; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.direct_award_searches
    ADD CONSTRAINT uq_direct_award_searches_id_project_id UNIQUE (id, project_id);


--
-- Name: lots uq_lots_id_one_service_limit; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lots
    ADD CONSTRAINT uq_lots_id_one_service_limit UNIQUE (id, one_service_limit);


--
-- Name: outcomes uq_outcomes_external_id; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.outcomes
    ADD CONSTRAINT uq_outcomes_external_id UNIQUE (external_id);


--
-- Name: services uq_services_service_id; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT uq_services_service_id UNIQUE (service_id);


--
-- Name: suppliers uq_suppliers_duns_number; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT uq_suppliers_duns_number UNIQUE (duns_number);


--
-- Name: users uq_users_email_address; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT uq_users_email_address UNIQUE (email_address);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: idx_audit_events_created_at_per_obj_partial; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_events_created_at_per_obj_partial ON public.audit_events USING btree (object_type, object_id, created_at, id) WHERE ((acknowledged = false) AND ((type)::text = 'update_service'::text));


--
-- Name: idx_audit_events_data_draft_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_events_data_draft_id ON public.audit_events USING btree (((data ->> 'draftId'::text))) WHERE ((data ->> 'draftId'::text) IS NOT NULL);


--
-- Name: idx_audit_events_data_supplier_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_events_data_supplier_id ON public.audit_events USING btree (COALESCE((data ->> 'supplierId'::text), (data ->> 'supplier_id'::text))) WHERE (COALESCE((data ->> 'supplierId'::text), (data ->> 'supplier_id'::text)) IS NOT NULL);


--
-- Name: idx_audit_events_object_and_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_events_object_and_type ON public.audit_events USING btree (object_type, object_id, type, created_at);


--
-- Name: idx_audit_events_type_acknowledged; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_events_type_acknowledged ON public.audit_events USING btree (type, acknowledged);


--
-- Name: idx_brief_responses_unique_awarded_at_per_brief_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_brief_responses_unique_awarded_at_per_brief_id ON public.brief_responses USING btree (brief_id) WHERE (awarded_at IS NOT NULL);


--
-- Name: idx_draft_services_enforce_one_service_limit; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_draft_services_enforce_one_service_limit ON public.draft_services USING btree (supplier_id, lot_id, framework_id) WHERE lot_one_service_limit;


--
-- Name: idx_outcomes_completed_brief_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_outcomes_completed_brief_unique ON public.outcomes USING btree (brief_id) WHERE (completed_at IS NOT NULL);


--
-- Name: idx_outcomes_completed_direct_award_project_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_outcomes_completed_direct_award_project_unique ON public.outcomes USING btree (direct_award_project_id) WHERE (completed_at IS NOT NULL);


--
-- Name: idx_project_id_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_project_id_active ON public.direct_award_searches USING btree (project_id, active) WHERE active;


--
-- Name: ix_archived_services_framework_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_archived_services_framework_id ON public.archived_services USING btree (framework_id);


--
-- Name: ix_archived_services_lot_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_archived_services_lot_id ON public.archived_services USING btree (lot_id);


--
-- Name: ix_archived_services_service_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_archived_services_service_id ON public.archived_services USING btree (service_id);


--
-- Name: ix_archived_services_supplier_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_archived_services_supplier_id ON public.archived_services USING btree (supplier_id);


--
-- Name: ix_audit_events_acknowledged; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_events_acknowledged ON public.audit_events USING btree (acknowledged);


--
-- Name: ix_audit_events_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_events_created_at ON public.audit_events USING btree (created_at);


--
-- Name: ix_audit_events_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_events_type ON public.audit_events USING btree (type);


--
-- Name: ix_brief_clarification_questions_published_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_brief_clarification_questions_published_at ON public.brief_clarification_questions USING btree (published_at);


--
-- Name: ix_brief_responses_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_brief_responses_created_at ON public.brief_responses USING btree (created_at);


--
-- Name: ix_briefs_cancelled_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_briefs_cancelled_at ON public.briefs USING btree (cancelled_at);


--
-- Name: ix_briefs_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_briefs_created_at ON public.briefs USING btree (created_at);


--
-- Name: ix_briefs_published_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_briefs_published_at ON public.briefs USING btree (published_at);


--
-- Name: ix_briefs_unsuccessful_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_briefs_unsuccessful_at ON public.briefs USING btree (unsuccessful_at);


--
-- Name: ix_briefs_updated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_briefs_updated_at ON public.briefs USING btree (updated_at);


--
-- Name: ix_briefs_withdrawn_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_briefs_withdrawn_at ON public.briefs USING btree (withdrawn_at);


--
-- Name: ix_direct_award_project_users_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_direct_award_project_users_project_id ON public.direct_award_project_users USING btree (project_id);


--
-- Name: ix_direct_award_project_users_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_direct_award_project_users_user_id ON public.direct_award_project_users USING btree (user_id);


--
-- Name: ix_direct_award_search_result_entries_archived_service_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_direct_award_search_result_entries_archived_service_id ON public.direct_award_search_result_entries USING btree (archived_service_id);


--
-- Name: ix_direct_award_search_result_entries_search_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_direct_award_search_result_entries_search_id ON public.direct_award_search_result_entries USING btree (search_id);


--
-- Name: ix_direct_award_searches_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_direct_award_searches_active ON public.direct_award_searches USING btree (active);


--
-- Name: ix_direct_award_searches_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_direct_award_searches_project_id ON public.direct_award_searches USING btree (project_id);


--
-- Name: ix_draft_services_framework_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_draft_services_framework_id ON public.draft_services USING btree (framework_id);


--
-- Name: ix_draft_services_lot_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_draft_services_lot_id ON public.draft_services USING btree (lot_id);


--
-- Name: ix_draft_services_service_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_draft_services_service_id ON public.draft_services USING btree (service_id);


--
-- Name: ix_draft_services_supplier_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_draft_services_supplier_id ON public.draft_services USING btree (supplier_id);


--
-- Name: ix_frameworks_framework; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_frameworks_framework ON public.frameworks USING btree (framework);


--
-- Name: ix_frameworks_slug; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_frameworks_slug ON public.frameworks USING btree (slug);


--
-- Name: ix_frameworks_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_frameworks_status ON public.frameworks USING btree (status);


--
-- Name: ix_lots_slug; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_lots_slug ON public.lots USING btree (slug);


--
-- Name: ix_service_ordering; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_service_ordering ON public.services USING btree (framework_id, ((data ->> 'lot'::text)), ((data ->> 'serviceName'::text)));


--
-- Name: ix_services_framework_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_services_framework_id ON public.services USING btree (framework_id);


--
-- Name: ix_services_lot_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_services_lot_id ON public.services USING btree (lot_id);


--
-- Name: ix_services_supplier_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_services_supplier_id ON public.services USING btree (supplier_id);


--
-- Name: ix_suppliers_supplier_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_suppliers_supplier_id ON public.suppliers USING btree (supplier_id);


--
-- Name: ix_users_supplier_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_users_supplier_id ON public.users USING btree (supplier_id);


--
-- Name: archived_services archived_services_framework_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.archived_services
    ADD CONSTRAINT archived_services_framework_id_fkey FOREIGN KEY (framework_id) REFERENCES public.frameworks(id);


--
-- Name: archived_services archived_services_framework_id_fkey1; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.archived_services
    ADD CONSTRAINT archived_services_framework_id_fkey1 FOREIGN KEY (framework_id, lot_id) REFERENCES public.framework_lots(framework_id, lot_id);


--
-- Name: archived_services archived_services_lot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.archived_services
    ADD CONSTRAINT archived_services_lot_id_fkey FOREIGN KEY (lot_id) REFERENCES public.lots(id);


--
-- Name: archived_services archived_services_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.archived_services
    ADD CONSTRAINT archived_services_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(supplier_id);


--
-- Name: brief_clarification_questions brief_clarification_questions_brief_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.brief_clarification_questions
    ADD CONSTRAINT brief_clarification_questions_brief_id_fkey FOREIGN KEY (brief_id) REFERENCES public.briefs(id);


--
-- Name: brief_responses brief_responses_brief_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.brief_responses
    ADD CONSTRAINT brief_responses_brief_id_fkey FOREIGN KEY (brief_id) REFERENCES public.briefs(id);


--
-- Name: brief_responses brief_responses_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.brief_responses
    ADD CONSTRAINT brief_responses_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(supplier_id);


--
-- Name: brief_users brief_users_brief_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.brief_users
    ADD CONSTRAINT brief_users_brief_id_fkey FOREIGN KEY (brief_id) REFERENCES public.briefs(id);


--
-- Name: brief_users brief_users_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.brief_users
    ADD CONSTRAINT brief_users_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: briefs briefs_framework_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.briefs
    ADD CONSTRAINT briefs_framework_id_fkey FOREIGN KEY (framework_id) REFERENCES public.frameworks(id);


--
-- Name: briefs briefs_framework_id_fkey1; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.briefs
    ADD CONSTRAINT briefs_framework_id_fkey1 FOREIGN KEY (framework_id, lot_id) REFERENCES public.framework_lots(framework_id, lot_id);


--
-- Name: briefs briefs_lot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.briefs
    ADD CONSTRAINT briefs_lot_id_fkey FOREIGN KEY (lot_id) REFERENCES public.lots(id);


--
-- Name: contact_information contact_information_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contact_information
    ADD CONSTRAINT contact_information_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(supplier_id);


--
-- Name: direct_award_project_users direct_award_project_users_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.direct_award_project_users
    ADD CONSTRAINT direct_award_project_users_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.direct_award_projects(id);


--
-- Name: direct_award_project_users direct_award_project_users_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.direct_award_project_users
    ADD CONSTRAINT direct_award_project_users_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: direct_award_search_result_entries direct_award_search_result_entries_archived_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.direct_award_search_result_entries
    ADD CONSTRAINT direct_award_search_result_entries_archived_service_id_fkey FOREIGN KEY (archived_service_id) REFERENCES public.archived_services(id);


--
-- Name: direct_award_search_result_entries direct_award_search_result_entries_search_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.direct_award_search_result_entries
    ADD CONSTRAINT direct_award_search_result_entries_search_id_fkey FOREIGN KEY (search_id) REFERENCES public.direct_award_searches(id);


--
-- Name: direct_award_searches direct_award_searches_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.direct_award_searches
    ADD CONSTRAINT direct_award_searches_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: direct_award_searches direct_award_searches_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.direct_award_searches
    ADD CONSTRAINT direct_award_searches_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.direct_award_projects(id);


--
-- Name: draft_services draft_services_framework_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.draft_services
    ADD CONSTRAINT draft_services_framework_id_fkey FOREIGN KEY (framework_id) REFERENCES public.frameworks(id);


--
-- Name: draft_services draft_services_framework_id_fkey1; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.draft_services
    ADD CONSTRAINT draft_services_framework_id_fkey1 FOREIGN KEY (framework_id, lot_id) REFERENCES public.framework_lots(framework_id, lot_id);


--
-- Name: draft_services draft_services_lot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.draft_services
    ADD CONSTRAINT draft_services_lot_id_fkey FOREIGN KEY (lot_id) REFERENCES public.lots(id);


--
-- Name: draft_services draft_services_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.draft_services
    ADD CONSTRAINT draft_services_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(supplier_id);


--
-- Name: draft_services fk_draft_services_lot_id_one_service_limit; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.draft_services
    ADD CONSTRAINT fk_draft_services_lot_id_one_service_limit FOREIGN KEY (lot_id, lot_one_service_limit) REFERENCES public.lots(id, one_service_limit);


--
-- Name: outcomes fk_outcomes_brief_response_id_brief_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.outcomes
    ADD CONSTRAINT fk_outcomes_brief_response_id_brief_id FOREIGN KEY (brief_response_id, brief_id) REFERENCES public.brief_responses(id, brief_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: outcomes fk_outcomes_da_search_id_da_project_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.outcomes
    ADD CONSTRAINT fk_outcomes_da_search_id_da_project_id FOREIGN KEY (direct_award_search_id, direct_award_project_id) REFERENCES public.direct_award_searches(id, project_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: outcomes fk_outcomes_da_service_id_da_search_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.outcomes
    ADD CONSTRAINT fk_outcomes_da_service_id_da_search_id FOREIGN KEY (direct_award_archived_service_id, direct_award_search_id) REFERENCES public.direct_award_search_result_entries(archived_service_id, search_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: supplier_frameworks fk_supplier_frameworks_prefill_declaration_from_framework_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplier_frameworks
    ADD CONSTRAINT fk_supplier_frameworks_prefill_declaration_from_framework_id FOREIGN KEY (prefill_declaration_from_framework_id) REFERENCES public.frameworks(id);


--
-- Name: supplier_frameworks fk_supplier_frameworks_supplier_id_supplier_frameworks; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplier_frameworks
    ADD CONSTRAINT fk_supplier_frameworks_supplier_id_supplier_frameworks FOREIGN KEY (supplier_id, prefill_declaration_from_framework_id) REFERENCES public.supplier_frameworks(supplier_id, framework_id);


--
-- Name: framework_agreements framework_agreements_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.framework_agreements
    ADD CONSTRAINT framework_agreements_supplier_id_fkey FOREIGN KEY (supplier_id, framework_id) REFERENCES public.supplier_frameworks(supplier_id, framework_id);


--
-- Name: framework_lots framework_lots_framework_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.framework_lots
    ADD CONSTRAINT framework_lots_framework_id_fkey FOREIGN KEY (framework_id) REFERENCES public.frameworks(id);


--
-- Name: framework_lots framework_lots_lot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.framework_lots
    ADD CONSTRAINT framework_lots_lot_id_fkey FOREIGN KEY (lot_id) REFERENCES public.lots(id);


--
-- Name: outcomes outcomes_brief_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.outcomes
    ADD CONSTRAINT outcomes_brief_id_fkey FOREIGN KEY (brief_id) REFERENCES public.briefs(id);


--
-- Name: outcomes outcomes_brief_response_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.outcomes
    ADD CONSTRAINT outcomes_brief_response_id_fkey FOREIGN KEY (brief_response_id) REFERENCES public.brief_responses(id);


--
-- Name: outcomes outcomes_direct_award_archived_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.outcomes
    ADD CONSTRAINT outcomes_direct_award_archived_service_id_fkey FOREIGN KEY (direct_award_archived_service_id) REFERENCES public.archived_services(id);


--
-- Name: outcomes outcomes_direct_award_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.outcomes
    ADD CONSTRAINT outcomes_direct_award_project_id_fkey FOREIGN KEY (direct_award_project_id) REFERENCES public.direct_award_projects(id);


--
-- Name: outcomes outcomes_direct_award_search_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.outcomes
    ADD CONSTRAINT outcomes_direct_award_search_id_fkey FOREIGN KEY (direct_award_search_id) REFERENCES public.direct_award_searches(id);


--
-- Name: services services_framework_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_framework_id_fkey FOREIGN KEY (framework_id) REFERENCES public.frameworks(id);


--
-- Name: services services_framework_id_fkey1; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_framework_id_fkey1 FOREIGN KEY (framework_id, lot_id) REFERENCES public.framework_lots(framework_id, lot_id);


--
-- Name: services services_lot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_lot_id_fkey FOREIGN KEY (lot_id) REFERENCES public.lots(id);


--
-- Name: services services_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(supplier_id);


--
-- Name: supplier_frameworks supplier_frameworks_framework_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplier_frameworks
    ADD CONSTRAINT supplier_frameworks_framework_id_fkey FOREIGN KEY (framework_id) REFERENCES public.frameworks(id);


--
-- Name: supplier_frameworks supplier_frameworks_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplier_frameworks
    ADD CONSTRAINT supplier_frameworks_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(supplier_id);


--
-- Name: users users_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(supplier_id);


--
-- Name: forbid_ddl_reader; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER forbid_ddl_reader ON ddl_command_start
   EXECUTE FUNCTION public.forbid_ddl_reader();


--
-- Name: make_readable; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER make_readable ON ddl_command_end
         WHEN TAG IN ('CREATE TABLE', 'CREATE TABLE AS', 'CREATE SCHEMA', 'CREATE VIEW', 'CREATE SEQUENCE')
   EXECUTE FUNCTION public.make_readable();

--
-- PostgreSQL database dump complete
--
